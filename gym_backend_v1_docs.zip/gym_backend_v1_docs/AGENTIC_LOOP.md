# AGENTIC LOOP - Backend Gym Management SaaS V1

Dokumen ini adalah instruksi agentic loop untuk Codex/Claude Code saat membangun backend.

## 0. Goal Utama

Bangun backend API **Gym Management SaaS V1** dengan stack:

- Go
- Gin Framework
- PostgreSQL
- Redis
- Docker Compose
- SQL migration
- Hot reload Air

Core bisnis V1:

- Auth admin
- Gym profile
- User/staff
- Member
- Membership package
- Subscription
- Payment
- Expense category
- Expense
- QR member
- Member check-in
- Reminder rule
- Reminder log
- Dashboard report
- Audit log
- Public member API berbasis `qr_token`

## 1. Operating Mode Agent

Setiap agent/AI coding assistant wajib mengikuti loop ini:

```text
PLAN -> IMPLEMENT -> SELF-CHECK -> RUN/TEST -> FIX -> DOCUMENT -> NEXT
```

### PLAN

Sebelum coding:

1. Baca dokumen terkait.
2. Identifikasi modul yang sedang dikerjakan.
3. Cek dependency modul.
4. Tentukan file yang akan dibuat/diubah.
5. Jangan mengubah area yang tidak berhubungan.

### IMPLEMENT

Saat coding:

1. Ikuti struktur folder di `Patterncode-structurepath.md`.
2. Controller hanya handle HTTP request/response.
3. Service handle business logic dan transaction.
4. Repository handle query database.
5. Models berisi struct database dan base query/helper query.
6. Helper untuk fungsi reusable.
7. Middleware untuk auth, role, request id, recover, CORS.

### SELF-CHECK

Sebelum lanjut:

1. Pastikan code compile.
2. Pastikan import tidak unused.
3. Pastikan error handling konsisten.
4. Pastikan semua query admin scoped by `gym_id`.
5. Pastikan response format konsisten.
6. Pastikan migration up/down tersedia.
7. Pastikan public endpoint tidak leak data sensitif.

### RUN/TEST

Minimal jalankan:

```bash
go test ./...
go vet ./...
go fmt ./...
```

Jika Docker tersedia:

```bash
docker compose up -d
make migrate-up
make dev
```

### FIX

Jika error:

1. Baca error.
2. Fix akar masalah.
3. Jangan patch asal.
4. Ulangi test.

### DOCUMENT

Jika menambahkan endpoint/modul:

1. Update route list.
2. Update payload contoh jika berubah.
3. Update migration note jika ada perubahan schema.

### NEXT

Lanjut modul berikutnya sesuai urutan roadmap.

---

## 2. Roadmap Implementasi V1

Kerjakan berurutan seperti ini.

### Phase 1 - Foundation

Target:

- Project Go siap jalan.
- Docker Compose siap.
- PostgreSQL dan Redis aktif.
- Hot reload Air aktif.
- Config/env siap.
- DB connection siap.
- Redis connection siap.
- Migration tool siap.
- Health check endpoint siap.

Tasks:

```text
1. Init go module.
2. Install dependencies.
3. Buat Dockerfile dev.
4. Buat docker-compose.yml.
5. Buat .air.toml.
6. Buat Makefile.
7. Buat config loader.
8. Buat database postgres connection pool.
9. Buat redis client.
10. Buat health endpoint.
```

Dependencies yang disarankan:

```bash
go get github.com/gin-gonic/gin
go get github.com/jackc/pgx/v5/pgxpool
go get github.com/redis/go-redis/v9
go get github.com/golang-jwt/jwt/v5
go get golang.org/x/crypto/bcrypt
go get github.com/google/uuid
go get github.com/go-playground/validator/v10
go get github.com/joho/godotenv
```

Catatan:

- Gunakan `pgxpool`, bukan `database/sql` biasa, agar Postgres lebih nyaman.
- Gunakan context timeout untuk query.

### Phase 2 - Migration Schema

Target:

- Semua tabel V1 tersedia.
- Foreign key benar.
- Index benar.
- Partial unique index check-in valid per hari tersedia.

Tasks:

```text
1. Buat migrations/000001_create_core_schema.up.sql
2. Buat migrations/000001_create_core_schema.down.sql
3. Jalankan migrate-up.
4. Pastikan migrate-down bisa jalan.
```

Migration wajib memuat:

- gyms
- users
- members
- membership_packages
- subscriptions
- payments
- expense_categories
- expenses
- member_qrcodes
- member_checkins
- reminder_rules
- reminder_logs
- audit_logs

Partial unique index wajib:

```sql
CREATE UNIQUE INDEX uniq_valid_checkin_per_member_per_day
ON member_checkins (gym_id, member_id, checkin_date)
WHERE status = 'valid';
```

### Phase 3 - Shared Helpers & Base Pattern

Target:

- Response helper
- Pagination helper
- Error helper
- Validation helper
- Auth JWT helper
- Password helper
- Date/time helper
- QR token helper
- Audit helper

Tasks:

```text
1. Buat pkg/response.
2. Buat pkg/pagination.
3. Buat pkg/errors.
4. Buat pkg/auth.
5. Buat pkg/hash.
6. Buat pkg/datetime.
7. Buat pkg/token.
8. Buat pkg/audit.
```

Standard response:

```json
{
  "success": true,
  "message": "Berhasil",
  "data": {}
}
```

Error response:

```json
{
  "success": false,
  "message": "Data tidak ditemukan",
  "errors": null
}
```

Pagination response:

```json
{
  "success": true,
  "data": [],
  "meta": {
    "page": 1,
    "limit": 10,
    "total": 100,
    "total_page": 10
  }
}
```

### Phase 4 - Auth Admin

Target:

- Admin login.
- JWT access token.
- Refresh token sederhana via Redis.
- Middleware auth.
- Middleware role.
- Profile endpoint.

Endpoint:

```http
POST /api/v1/admin/auth/login
POST /api/v1/admin/auth/logout
POST /api/v1/admin/auth/refresh
GET  /api/v1/admin/auth/profile
```

Rules:

- Login pakai email + password.
- Email scoped by gym via unique `(gym_id, email)`, tapi login V1 bisa cari email global terlebih dahulu. Jika nanti multi-gym satu email butuh pilih gym, buat V1 cukup assume email unik secara operasional atau tambah `gym_public_id` pada login.
- Password pakai bcrypt.
- JWT claims minimal: `user_id`, `user_public_id`, `gym_id`, `gym_public_id`, `role`.
- Refresh token simpan di Redis dengan TTL.

### Phase 5 - Gym, Users, Members

Target:

- Gym profile CRUD terbatas.
- Staff CRUD.
- Member CRUD.

Rules:

- Semua list support pagination.
- Semua list support search/filter minimal sesuai endpoint.
- Delete user/member = deactivate/status inactive, bukan hard delete.
- Audit log untuk create/update/delete.

### Phase 6 - Packages, Subscriptions, Payments

Target:

- Package CRUD.
- Subscription CRUD minimal.
- Payment membership otomatis membuat subscription.
- Cancel/refund payment.

Business rules payment membership:

```text
1. Ambil member aktif.
2. Ambil package aktif.
3. Hitung package_price, discount_amount, final_amount.
4. Buat subscription active.
5. Buat payment paid/pending.
6. Generate invoice_no unik per gym.
7. Audit log.
```

Invoice format disarankan:

```text
INV-{YYYYMMDD}-{sequence 4 digit}
```

Contoh:

```text
INV-20260616-0001
```

### Phase 7 - Expenses

Target:

- Expense category CRUD.
- Expense CRUD.
- Approve/reject expense.

Rules:

- Expense status: draft, approved, rejected.
- Hanya approved masuk laporan profit-loss.

### Phase 8 - QR Member & Check-in

Target:

- Generate QR token member.
- Regenerate QR.
- Revoke QR.
- Admin scan QR.
- Manual check-in.
- Public member scan QR.
- Check-in history.

Rules scan QR:

```text
1. Validate qr_token exists and active.
2. Validate member active.
3. Find active subscription where start_date <= today and end_date >= today.
4. If no active subscription, record check-in as expired and return error.
5. If valid check-in already exists today, record duplicate attempt optional, return duplicate.
6. Else create member_checkins status valid.
```

Public endpoint must not expose:

- Email
- Address
- Emergency contact
- Notes internal
- Payment detail
- Audit log

### Phase 9 - Reminder

Target:

- Reminder rule CRUD.
- Reminder log list.
- Retry reminder log placeholder.

V1 tidak wajib integrasi WhatsApp beneran. Buat interface/provider stub agar nanti mudah disambung.

Rules:

- reminder_rules menentukan H-berapa sebelum expired.
- reminder_logs menyimpan status pending/sent/failed.

### Phase 10 - Reports & Audit

Target:

- Dashboard summary.
- Payment report.
- Expense report.
- Profit-loss.
- Check-in report.
- Expired members.
- Audit log list.

Dashboard minimal:

```text
total_active_members
total_expired_members
income_this_month
expense_this_month
net_profit_this_month
checkins_today
payment_pending
reminder_failed
```

---

## 3. Definition of Done

Sebuah modul dianggap selesai jika:

1. Migration ada jika perlu schema baru.
2. Model ada.
3. Repository ada.
4. Service ada.
5. Controller ada.
6. DTO request/response ada.
7. Route terdaftar.
8. Auth/role middleware sesuai.
9. Response format konsisten.
10. Error handling rapi.
11. Query scoped by `gym_id`.
12. Audit log untuk aksi penting.
13. `go test ./...` tidak error.
14. `go fmt ./...` sudah dijalankan.

---

## 4. Agent Guardrails

Wajib:

- Gunakan `public_id` di path endpoint.
- Jangan expose internal numeric `id` pada response kecuali untuk internal debug yang tidak dipakai public.
- Jangan hardcode timezone selain dari gym config, default Asia/Jakarta.
- Jangan skip validasi input.
- Jangan skip transaction untuk operasi multi-table.
- Jangan campur business logic ke controller.
- Jangan query data tanpa `gym_id` di admin endpoint.
- Jangan buat raw SQL berulang-ulang kalau bisa dijadikan helper/base query.

Boleh:

- Gunakan raw SQL via pgx.
- Buat helper query builder sederhana.
- Buat interface repository/service agar testable.
- Buat seed default owner/gym untuk dev.

Tidak perlu V1:

- RBAC dinamis.
- Payment gateway QRIS real.
- WhatsApp provider real.
- Workout schedule V2.
- POS produk.
- SaaS billing untuk owner gym.
