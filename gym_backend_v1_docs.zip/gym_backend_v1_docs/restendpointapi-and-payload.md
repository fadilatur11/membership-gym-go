# restendpointapi-and-payload.md - REST API V1

Base path:

```http
/api/v1
```

Endpoint dibagi menjadi:

```http
/api/v1/admin
/api/v1/member
```

## Standard Response

### Success

```json
{
  "success": true,
  "message": "Berhasil",
  "data": {}
}
```

### Error

```json
{
  "success": false,
  "message": "Data tidak ditemukan",
  "errors": null
}
```

### Pagination

```json
{
  "success": true,
  "data": [],
  "meta": {
    "page": 1,
    "limit": 10,
    "total": 100,
    "total_page": 10
  }
}
```

---

# A. Admin API

Semua admin endpoint kecuali login/refresh membutuhkan:

```http
Authorization: Bearer {access_token}
```

---

## 1. Auth Admin

### Login

```http
POST /api/v1/admin/auth/login
```

Request:

```json
{
  "email": "owner@gym.com",
  "password": "password"
}
```

Optional jika nanti email bisa sama di banyak gym:

```json
{
  "gym_public_id": "gym-public-id",
  "email": "owner@gym.com",
  "password": "password"
}
```

Response:

```json
{
  "success": true,
  "message": "Login berhasil",
  "data": {
    "access_token": "jwt-token",
    "refresh_token": "refresh-token",
    "user": {
      "public_id": "user-public-id",
      "name": "Owner Gym",
      "email": "owner@gym.com",
      "role": "owner"
    },
    "gym": {
      "public_id": "gym-public-id",
      "name": "Gym Sehat"
    }
  }
}
```

### Logout

```http
POST /api/v1/admin/auth/logout
```

Request:

```json
{
  "refresh_token": "refresh-token"
}
```

### Refresh Token

```http
POST /api/v1/admin/auth/refresh
```

Request:

```json
{
  "refresh_token": "refresh-token"
}
```

### Profile

```http
GET /api/v1/admin/auth/profile
```

---

## 2. Gym Profile

```http
GET   /api/v1/admin/gym/profile
PATCH /api/v1/admin/gym/profile
```

Patch request:

```json
{
  "name": "Gym Sehat",
  "phone": "08123456789",
  "email": "admin@gym.com",
  "address": "Jl. Contoh No. 1",
  "timezone": "Asia/Jakarta",
  "currency": "IDR"
}
```

---

## 3. Users / Staff

```http
GET    /api/v1/admin/users
POST   /api/v1/admin/users
GET    /api/v1/admin/users/{user_public_id}
PATCH  /api/v1/admin/users/{user_public_id}
DELETE /api/v1/admin/users/{user_public_id}
```

List query:

```http
GET /api/v1/admin/users?search=andi&role=trainer&is_active=true&page=1&limit=10
```

Create request:

```json
{
  "name": "Andi Trainer",
  "email": "andi@gym.com",
  "password": "secret123",
  "role": "trainer"
}
```

Patch request:

```json
{
  "name": "Andi Updated",
  "role": "cashier",
  "is_active": true
}
```

---

## 4. Members

```http
GET    /api/v1/admin/members
POST   /api/v1/admin/members
GET    /api/v1/admin/members/{member_public_id}
PATCH  /api/v1/admin/members/{member_public_id}
DELETE /api/v1/admin/members/{member_public_id}
```

List query:

```http
GET /api/v1/admin/members?search=budi&status=active&page=1&limit=10
```

Create request:

```json
{
  "member_code": "MBR-001",
  "full_name": "Budi Santoso",
  "phone": "08123456789",
  "email": "budi@email.com",
  "gender": "male",
  "birth_date": "1998-01-10",
  "address": "Probolinggo",
  "emergency_contact_name": "Siti",
  "emergency_contact_phone": "08999999999",
  "joined_at": "2026-06-16",
  "notes": "Member baru"
}
```

Patch request:

```json
{
  "full_name": "Budi Santoso Updated",
  "phone": "08123456789",
  "status": "active",
  "notes": "Updated notes"
}
```

---

## 5. Member QR Code

```http
GET  /api/v1/admin/members/{member_public_id}/qrcode
POST /api/v1/admin/members/{member_public_id}/qrcode/generate
POST /api/v1/admin/members/{member_public_id}/qrcode/regenerate
POST /api/v1/admin/members/{member_public_id}/qrcode/revoke
```

Get/generate response:

```json
{
  "success": true,
  "data": {
    "member_public_id": "member-public-id",
    "member_name": "Budi Santoso",
    "qr_token": "qr-token-random",
    "qr_content": "https://app-domain.com/member/checkin/qr-token-random",
    "status": "active"
  }
}
```

---

## 6. Membership Packages

```http
GET    /api/v1/admin/membership-packages
POST   /api/v1/admin/membership-packages
GET    /api/v1/admin/membership-packages/{package_public_id}
PATCH  /api/v1/admin/membership-packages/{package_public_id}
DELETE /api/v1/admin/membership-packages/{package_public_id}
```

Create request:

```json
{
  "name": "Bulanan",
  "duration_days": 30,
  "price": 300000,
  "description": "Membership 30 hari"
}
```

Patch request:

```json
{
  "name": "Bulanan Promo",
  "duration_days": 30,
  "price": 250000,
  "description": "Promo bulan ini",
  "is_active": true
}
```

---

## 7. Subscriptions

```http
GET   /api/v1/admin/subscriptions
POST  /api/v1/admin/subscriptions
GET   /api/v1/admin/subscriptions/{subscription_public_id}
PATCH /api/v1/admin/subscriptions/{subscription_public_id}/cancel
PATCH /api/v1/admin/subscriptions/{subscription_public_id}/expire
```

List query:

```http
GET /api/v1/admin/subscriptions?status=active&member_public_id=xxx&page=1&limit=10
```

Create manual request:

```json
{
  "member_public_id": "member-public-id",
  "membership_package_public_id": "package-public-id",
  "start_date": "2026-06-16"
}
```

Response:

```json
{
  "success": true,
  "message": "Subscription berhasil dibuat",
  "data": {
    "public_id": "subscription-public-id",
    "member_name": "Budi Santoso",
    "package_name": "Bulanan",
    "start_date": "2026-06-16",
    "end_date": "2026-07-15",
    "status": "active"
  }
}
```

---

## 8. Payments

```http
GET   /api/v1/admin/payments
POST  /api/v1/admin/payments
GET   /api/v1/admin/payments/{payment_public_id}
PATCH /api/v1/admin/payments/{payment_public_id}/cancel
PATCH /api/v1/admin/payments/{payment_public_id}/refund
```

List query:

```http
GET /api/v1/admin/payments?start_date=2026-06-01&end_date=2026-06-30&status=paid&page=1&limit=10
```

Create membership payment request:

```json
{
  "member_public_id": "member-public-id",
  "membership_package_public_id": "package-public-id",
  "start_date": "2026-06-16",
  "payment_method": "cash",
  "discount_amount": 50000,
  "status": "paid",
  "notes": "Promo member lama"
}
```

Response:

```json
{
  "success": true,
  "message": "Pembayaran berhasil",
  "data": {
    "invoice_no": "INV-20260616-0001",
    "member_name": "Budi Santoso",
    "package_name": "Bulanan",
    "package_price": 300000,
    "discount_amount": 50000,
    "final_amount": 250000,
    "payment_method": "cash",
    "status": "paid",
    "subscription": {
      "public_id": "subscription-public-id",
      "start_date": "2026-06-16",
      "end_date": "2026-07-15",
      "status": "active"
    }
  }
}
```

Cancel/refund request:

```json
{
  "notes": "Salah input pembayaran"
}
```

---

## 9. Check-ins

```http
POST /api/v1/admin/checkins/scan
POST /api/v1/admin/checkins/manual
GET  /api/v1/admin/checkins
GET  /api/v1/admin/checkins/today
GET  /api/v1/admin/members/{member_public_id}/checkins
```

Scan QR request:

```json
{
  "qr_token": "qr-token-random"
}
```

Success response:

```json
{
  "success": true,
  "message": "Check-in berhasil",
  "data": {
    "member_public_id": "member-public-id",
    "member_code": "MBR-001",
    "member_name": "Budi Santoso",
    "checkin_at": "2026-06-16 10:30:00",
    "subscription_end_date": "2026-07-15",
    "status": "valid"
  }
}
```

Expired response:

```json
{
  "success": false,
  "message": "Membership sudah expired",
  "data": {
    "member_public_id": "member-public-id",
    "member_code": "MBR-001",
    "member_name": "Budi Santoso",
    "subscription_end_date": "2026-06-10",
    "status": "expired"
  }
}
```

Duplicate response:

```json
{
  "success": false,
  "message": "Member sudah check-in hari ini",
  "data": {
    "member_public_id": "member-public-id",
    "member_name": "Budi Santoso",
    "last_checkin_at": "2026-06-16 08:15:00",
    "status": "duplicate"
  }
}
```

Manual check-in request:

```json
{
  "member_public_id": "member-public-id",
  "notes": "Manual check-in karena kamera bermasalah"
}
```

List query:

```http
GET /api/v1/admin/checkins?start_date=2026-06-01&end_date=2026-06-30&status=valid&page=1&limit=10
```

---

## 10. Expense Categories

```http
GET    /api/v1/admin/expense-categories
POST   /api/v1/admin/expense-categories
PATCH  /api/v1/admin/expense-categories/{category_public_id}
DELETE /api/v1/admin/expense-categories/{category_public_id}
```

Create request:

```json
{
  "name": "Listrik"
}
```

---

## 11. Expenses

```http
GET   /api/v1/admin/expenses
POST  /api/v1/admin/expenses
GET   /api/v1/admin/expenses/{expense_public_id}
PATCH /api/v1/admin/expenses/{expense_public_id}
PATCH /api/v1/admin/expenses/{expense_public_id}/approve
PATCH /api/v1/admin/expenses/{expense_public_id}/reject
```

Create request:

```json
{
  "expense_category_public_id": "category-public-id",
  "title": "Bayar listrik Juni",
  "description": "Token listrik",
  "amount": 500000,
  "expense_date": "2026-06-16",
  "status": "approved"
}
```

Approve/reject request:

```json
{
  "notes": "Disetujui owner"
}
```

---

## 12. Reminder Rules

```http
GET    /api/v1/admin/reminder-rules
POST   /api/v1/admin/reminder-rules
GET    /api/v1/admin/reminder-rules/{rule_public_id}
PATCH  /api/v1/admin/reminder-rules/{rule_public_id}
DELETE /api/v1/admin/reminder-rules/{rule_public_id}
```

Create request:

```json
{
  "name": "Reminder H-3",
  "days_before_expiry": 3,
  "channel": "whatsapp",
  "message_template": "Halo {{member_name}}, membership kamu akan habis pada {{end_date}}."
}
```

---

## 13. Reminder Logs

```http
GET  /api/v1/admin/reminder-logs
POST /api/v1/admin/reminder-logs/{log_public_id}/retry
```

List query:

```http
GET /api/v1/admin/reminder-logs?status=failed&page=1&limit=10
```

---

## 14. Reports

```http
GET /api/v1/admin/reports/dashboard
GET /api/v1/admin/reports/payments
GET /api/v1/admin/reports/expenses
GET /api/v1/admin/reports/profit-loss
GET /api/v1/admin/reports/checkins
GET /api/v1/admin/reports/expired-members
```

Dashboard query:

```http
GET /api/v1/admin/reports/dashboard?period=month
```

Dashboard response:

```json
{
  "success": true,
  "data": {
    "total_active_members": 120,
    "total_expired_members": 15,
    "income_this_month": 15000000,
    "expense_this_month": 4000000,
    "net_profit_this_month": 11000000,
    "checkins_today": 42,
    "payment_pending": 3,
    "reminder_failed": 1
  }
}
```

Profit-loss query:

```http
GET /api/v1/admin/reports/profit-loss?start_date=2026-06-01&end_date=2026-06-30
```

---

## 15. Audit Logs

```http
GET /api/v1/admin/audit-logs
```

Query:

```http
GET /api/v1/admin/audit-logs?entity_type=members&page=1&limit=20
```

---

# B. Public Member API

Base:

```http
/api/v1/member
```

Public API menggunakan `qr_token`, bukan login.

## 1. QR Identity

```http
GET /api/v1/member/qrcode/{qr_token}
```

Response:

```json
{
  "success": true,
  "data": {
    "member_name": "Budi Santoso",
    "member_code": "MBR-001",
    "gym_name": "Gym Sehat",
    "membership_status": "active",
    "subscription_end_date": "2026-07-15"
  }
}
```

---

## 2. Member Status

```http
GET /api/v1/member/status/{qr_token}
```

Response:

```json
{
  "success": true,
  "data": {
    "gym_name": "Gym Sehat",
    "member_name": "Budi Santoso",
    "member_code": "MBR-001",
    "member_status": "active",
    "membership_status": "active",
    "subscription_start_date": "2026-06-16",
    "subscription_end_date": "2026-07-15",
    "days_remaining": 30
  }
}
```

---

## 3. Public Check-in Scan

```http
POST /api/v1/member/checkins/scan
```

Request:

```json
{
  "qr_token": "qr-token-random"
}
```

Success response:

```json
{
  "success": true,
  "message": "Check-in berhasil",
  "data": {
    "gym_name": "Gym Sehat",
    "member_name": "Budi Santoso",
    "checkin_at": "2026-06-16 10:30:00",
    "subscription_end_date": "2026-07-15",
    "status": "valid"
  }
}
```

---

## 4. Public Check-in History

```http
GET /api/v1/member/checkins/{qr_token}
```

Query:

```http
GET /api/v1/member/checkins/{qr_token}?page=1&limit=10
```

Response:

```json
{
  "success": true,
  "data": [
    {
      "checkin_date": "2026-06-16",
      "checkin_at": "2026-06-16 10:30:00",
      "status": "valid",
      "source": "qr"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "total_page": 1
  }
}
```

---

## 5. Public Packages

```http
GET /api/v1/member/packages/{qr_token}
```

Response:

```json
{
  "success": true,
  "data": [
    {
      "name": "Bulanan",
      "duration_days": 30,
      "price": 300000,
      "description": "Membership 30 hari"
    }
  ]
}
```

---

## 6. Public Gym Contact

```http
GET /api/v1/member/gym/{qr_token}
```

Response:

```json
{
  "success": true,
  "data": {
    "gym_name": "Gym Sehat",
    "phone": "08123456789",
    "email": "admin@gym.com",
    "address": "Jl. Contoh No. 1"
  }
}
```
