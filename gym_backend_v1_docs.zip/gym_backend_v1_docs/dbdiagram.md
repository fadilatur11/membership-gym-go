# dbdiagram.md - Gym Management SaaS V1

Gunakan DBML ini sebagai source of truth schema V1.

```dbml
Project gym_management_saas {
  database_type: "PostgreSQL"
  note: "Gym Management SaaS V1 with QR Member Check-in"
}

Table gyms {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  name varchar [not null]
  phone varchar
  email varchar
  address text

  timezone varchar [default: 'Asia/Jakarta']
  currency varchar [default: 'IDR']
  status varchar [not null, default: 'active', note: 'active, inactive, suspended']

  created_at timestamp [not null]
  updated_at timestamp [not null]
}

Table users {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]

  name varchar [not null]
  email varchar [not null]
  password_hash varchar [not null]

  role varchar [not null, note: 'owner, admin, cashier, trainer']
  is_active boolean [not null, default: true]

  last_login_at timestamp

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, email) [unique]
    (gym_id, role)
    (gym_id, is_active)
  }
}

Table members {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]

  member_code varchar [not null]
  full_name varchar [not null]
  phone varchar
  email varchar
  gender varchar
  birth_date date
  address text

  emergency_contact_name varchar
  emergency_contact_phone varchar

  joined_at date [not null]
  status varchar [not null, default: 'active', note: 'active, inactive, banned']

  notes text

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, member_code) [unique]
    (gym_id, full_name)
    (gym_id, status)
    (gym_id, phone)
  }
}

Table membership_packages {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]

  name varchar [not null]
  duration_days int [not null]
  price bigint [not null]
  description text

  is_active boolean [not null, default: true]

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, name)
    (gym_id, is_active)
  }
}

Table subscriptions {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  member_id bigint [not null]
  membership_package_id bigint [not null]

  start_date date [not null]
  end_date date [not null]

  status varchar [not null, default: 'active', note: 'active, expired, cancelled']
  source varchar [default: 'manual', note: 'manual, renewal, system']

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, member_id)
    (gym_id, status)
    (gym_id, end_date)
    (gym_id, member_id, status)
  }
}

Table payments {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  member_id bigint [not null]
  subscription_id bigint

  invoice_no varchar [not null]

  payment_type varchar [not null, default: 'membership', note: 'membership, other']
  payment_method varchar [not null, note: 'cash, transfer, qris']

  package_price bigint [not null, default: 0]
  discount_amount bigint [not null, default: 0]
  final_amount bigint [not null]

  status varchar [not null, default: 'paid', note: 'paid, pending, cancelled, refunded']

  paid_at timestamp [not null]
  notes text

  created_by bigint

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, invoice_no) [unique]
    (gym_id, paid_at)
    (gym_id, status)
    (gym_id, member_id)
    (gym_id, payment_method)
  }
}

Table expense_categories {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]

  name varchar [not null]
  is_active boolean [not null, default: true]

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, name) [unique]
    (gym_id, is_active)
  }
}

Table expenses {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  expense_category_id bigint [not null]

  title varchar [not null]
  description text

  amount bigint [not null]
  expense_date date [not null]

  status varchar [not null, default: 'approved', note: 'draft, approved, rejected']

  created_by bigint

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, expense_date)
    (gym_id, status)
    (gym_id, expense_category_id)
  }
}

Table member_qrcodes {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  member_id bigint [not null]

  qr_token varchar [unique, not null]
  status varchar [not null, default: 'active', note: 'active, revoked']

  generated_at timestamp [not null]
  revoked_at timestamp

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, member_id)
    (gym_id, status)
    (qr_token) [unique]
  }
}

Table member_checkins {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  member_id bigint [not null]
  subscription_id bigint

  checkin_date date [not null]
  checkin_at timestamp [not null]

  source varchar [not null, default: 'qr', note: 'qr, manual']
  status varchar [not null, default: 'valid', note: 'valid, invalid_qr, expired, inactive_member, duplicate, cancelled']

  scanned_by bigint

  notes text

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, checkin_date)
    (gym_id, member_id)
    (gym_id, member_id, checkin_date)
    (gym_id, status)
    (gym_id, source)
  }
}

Table reminder_rules {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]

  name varchar [not null]
  days_before_expiry int [not null]
  channel varchar [not null, default: 'whatsapp', note: 'whatsapp, email']

  message_template text [not null]
  is_active boolean [not null, default: true]

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, is_active)
  }
}

Table reminder_logs {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  member_id bigint [not null]
  subscription_id bigint [not null]
  reminder_rule_id bigint [not null]

  channel varchar [not null, default: 'whatsapp', note: 'whatsapp, email']
  recipient varchar [not null]

  status varchar [not null, default: 'pending', note: 'pending, sent, failed']

  sent_at timestamp
  provider_message_id varchar
  error_message text

  created_at timestamp [not null]
  updated_at timestamp [not null]

  indexes {
    (gym_id, status)
    (gym_id, created_at)
    (subscription_id, reminder_rule_id, recipient)
  }
}

Table audit_logs {
  id bigint [pk, increment]
  public_id uuid [unique, not null]

  gym_id bigint [not null]
  user_id bigint

  action varchar [not null]
  entity_type varchar [not null]
  entity_id bigint

  payload json

  created_at timestamp [not null]

  indexes {
    (gym_id, created_at)
    (gym_id, entity_type)
    (gym_id, user_id)
  }
}

Ref: users.gym_id > gyms.id

Ref: members.gym_id > gyms.id

Ref: membership_packages.gym_id > gyms.id

Ref: subscriptions.gym_id > gyms.id
Ref: subscriptions.member_id > members.id
Ref: subscriptions.membership_package_id > membership_packages.id

Ref: payments.gym_id > gyms.id
Ref: payments.member_id > members.id
Ref: payments.subscription_id > subscriptions.id
Ref: payments.created_by > users.id

Ref: expense_categories.gym_id > gyms.id

Ref: expenses.gym_id > gyms.id
Ref: expenses.expense_category_id > expense_categories.id
Ref: expenses.created_by > users.id

Ref: member_qrcodes.gym_id > gyms.id
Ref: member_qrcodes.member_id > members.id

Ref: member_checkins.gym_id > gyms.id
Ref: member_checkins.member_id > members.id
Ref: member_checkins.subscription_id > subscriptions.id
Ref: member_checkins.scanned_by > users.id

Ref: reminder_rules.gym_id > gyms.id

Ref: reminder_logs.gym_id > gyms.id
Ref: reminder_logs.member_id > members.id
Ref: reminder_logs.subscription_id > subscriptions.id
Ref: reminder_logs.reminder_rule_id > reminder_rules.id

Ref: audit_logs.gym_id > gyms.id
Ref: audit_logs.user_id > users.id
```

## PostgreSQL Notes

DBML tidak cukup untuk partial unique index. Tambahkan di migration SQL:

```sql
CREATE UNIQUE INDEX uniq_valid_checkin_per_member_per_day
ON member_checkins (gym_id, member_id, checkin_date)
WHERE status = 'valid';
```

## Enum Rules V1

Gunakan string enum di Go.

### gyms.status

```text
active, inactive, suspended
```

### users.role

```text
owner, admin, cashier, trainer
```

### members.status

```text
active, inactive, banned
```

### subscriptions.status

```text
active, expired, cancelled
```

### payments.payment_method

```text
cash, transfer, qris
```

### payments.status

```text
paid, pending, cancelled, refunded
```

### expenses.status

```text
draft, approved, rejected
```

### member_qrcodes.status

```text
active, revoked
```

### member_checkins.source

```text
qr, manual
```

### member_checkins.status

```text
valid, invalid_qr, expired, inactive_member, duplicate, cancelled
```

### reminder_logs.status

```text
pending, sent, failed
```
