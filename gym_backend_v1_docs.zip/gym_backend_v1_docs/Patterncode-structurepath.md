# Patterncode-structurepath.md - Go Gin Backend Structure

Dokumen ini adalah acuan struktur kode backend Gym Management SaaS V1.

## 1. Stack

- Go
- Gin Framework
- PostgreSQL
- Redis
- Docker Compose
- Air hot reload
- golang-migrate/migrate
- pgxpool
- go-redis
- JWT
- bcrypt

## 2. Arsitektur

Gunakan pattern:

```text
Controller -> Service -> Repository -> Models/Base Query -> Database
```

Rules:

- Controller: HTTP binding, validation, response.
- Service: business logic, transaction, orchestration.
- Repository: SQL query dan persistence.
- Models: struct table, enum, base query, scan helper.
- Helper/pkg: fungsi reusable lintas modul.

## 3. Struktur Folder

```text
gym-management-saas-backend/
├── cmd/
│   └── api/
│       └── main.go
├── config/
│   └── config.go
├── database/
│   ├── postgres.go
│   └── redis.go
├── internal/
│   ├── app/
│   │   └── app.go
│   ├── routes/
│   │   ├── routes.go
│   │   ├── admin_routes.go
│   │   └── member_routes.go
│   ├── middleware/
│   │   ├── auth_middleware.go
│   │   ├── role_middleware.go
│   │   ├── cors_middleware.go
│   │   ├── request_id_middleware.go
│   │   └── recovery_middleware.go
│   ├── modules/
│   │   ├── auth/
│   │   │   ├── auth_controller.go
│   │   │   ├── auth_service.go
│   │   │   ├── auth_repository.go
│   │   │   ├── auth_dto.go
│   │   │   └── auth_routes.go
│   │   ├── gym/
│   │   ├── user/
│   │   ├── member/
│   │   ├── membership_package/
│   │   ├── subscription/
│   │   ├── payment/
│   │   ├── expense_category/
│   │   ├── expense/
│   │   ├── qrcode/
│   │   ├── checkin/
│   │   ├── reminder_rule/
│   │   ├── reminder_log/
│   │   ├── report/
│   │   └── audit/
│   └── models/
│       ├── base.go
│       ├── gym.go
│       ├── user.go
│       ├── member.go
│       ├── membership_package.go
│       ├── subscription.go
│       ├── payment.go
│       ├── expense_category.go
│       ├── expense.go
│       ├── member_qrcode.go
│       ├── member_checkin.go
│       ├── reminder_rule.go
│       ├── reminder_log.go
│       └── audit_log.go
├── pkg/
│   ├── response/
│   │   └── response.go
│   ├── pagination/
│   │   └── pagination.go
│   ├── errors/
│   │   └── app_error.go
│   ├── validator/
│   │   └── validator.go
│   ├── auth/
│   │   └── jwt.go
│   ├── hash/
│   │   └── bcrypt.go
│   ├── token/
│   │   └── token.go
│   ├── datetime/
│   │   └── datetime.go
│   ├── invoice/
│   │   └── invoice.go
│   └── sqlutil/
│       └── query.go
├── migrations/
│   ├── 000001_create_core_schema.up.sql
│   └── 000001_create_core_schema.down.sql
├── scripts/
│   └── seed_dev.sql
├── tmp/
├── .air.toml
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Makefile
├── go.mod
└── go.sum
```

## 4. Dependency Direction

```text
controller imports service
service imports repository + pkg/helper
repository imports models + pgxpool
models imports only standard lib if possible
pkg should not import internal modules
```

Jangan circular import.

## 5. Controller Pattern

Contoh controller method:

```go
func (c *MemberController) Create(ctx *gin.Context) {
    var req CreateMemberRequest
    if err := ctx.ShouldBindJSON(&req); err != nil {
        response.ValidationError(ctx, err)
        return
    }

    authUser := middleware.GetAuthUser(ctx)

    result, err := c.service.Create(ctx.Request.Context(), authUser, req)
    if err != nil {
        response.Error(ctx, err)
        return
    }

    response.Created(ctx, "Member berhasil dibuat", result)
}
```

Rules:

- Jangan query DB di controller.
- Jangan hitung bisnis di controller.
- Jangan return raw error ke client.

## 6. Service Pattern

Contoh service:

```go
func (s *MemberService) Create(ctx context.Context, authUser AuthUser, req CreateMemberRequest) (*MemberResponse, error) {
    if err := req.Validate(); err != nil {
        return nil, err
    }

    exists, err := s.repo.ExistsByMemberCode(ctx, authUser.GymID, req.MemberCode)
    if err != nil {
        return nil, err
    }
    if exists {
        return nil, apperror.Conflict("Kode member sudah digunakan")
    }

    member, err := s.repo.Create(ctx, CreateMemberParams{...})
    if err != nil {
        return nil, err
    }

    _ = s.audit.Log(ctx, authUser.GymID, &authUser.UserID, "member.created", "members", member.ID, member)

    return NewMemberResponse(member), nil
}
```

Rules:

- Service boleh memanggil lebih dari satu repository.
- Service wajib mengatur transaction untuk operasi multi-table.
- Service menentukan business error.

## 7. Repository Pattern

Contoh repository:

```go
type MemberRepository struct {
    db *pgxpool.Pool
}

func NewMemberRepository(db *pgxpool.Pool) *MemberRepository {
    return &MemberRepository{db: db}
}

func (r *MemberRepository) FindByPublicID(ctx context.Context, gymID int64, publicID uuid.UUID) (*models.Member, error) {
    query := `
        SELECT id, public_id, gym_id, member_code, full_name, phone, email, gender,
               birth_date, address, emergency_contact_name, emergency_contact_phone,
               joined_at, status, notes, created_at, updated_at
        FROM members
        WHERE gym_id = $1 AND public_id = $2
        LIMIT 1
    `

    row := r.db.QueryRow(ctx, query, gymID, publicID)
    return models.ScanMember(row)
}
```

Rules:

- Semua repository admin wajib menerima `gymID`.
- Repository tidak boleh tahu HTTP.
- Repository return model atau error.
- Gunakan `pgx.ErrNoRows` lalu mapping di service/helper.

## 8. Models & Base Query

`internal/models/base.go`:

```go
type BaseModel struct {
    ID        int64
    PublicID  uuid.UUID
    CreatedAt time.Time
    UpdatedAt time.Time
}

type BaseTenantModel struct {
    BaseModel
    GymID int64
}
```

Base query helper boleh ditempatkan di models/sqlutil:

```go
const DefaultLimit = 10
const MaxLimit = 100
```

Contoh model enum:

```go
type MemberStatus string

const (
    MemberStatusActive   MemberStatus = "active"
    MemberStatusInactive MemberStatus = "inactive"
    MemberStatusBanned   MemberStatus = "banned"
)
```

Rules:

- Jangan pakai string bebas di banyak tempat.
- Gunakan const enum.
- Gunakan scanner helper untuk row mapping.

## 9. Helper / pkg

### pkg/response

Fungsi wajib:

```go
OK(ctx, message string, data any)
Created(ctx, message string, data any)
NoContent(ctx)
Error(ctx, err error)
ValidationError(ctx, err error)
Paginated(ctx, data any, meta pagination.Meta)
```

### pkg/pagination

Fungsi wajib:

```go
Parse(ctx *gin.Context) Params
NewMeta(page, limit int, total int64) Meta
Offset() int
```

Rules:

- Default page = 1.
- Default limit = 10.
- Max limit = 100.

### pkg/errors

Buat typed error:

```go
BadRequest(message string)
Unauthorized(message string)
Forbidden(message string)
NotFound(message string)
Conflict(message string)
Internal(message string)
```

### pkg/auth

Fungsi:

```go
GenerateAccessToken(claims)
ParseAccessToken(token)
GenerateRefreshToken()
```

### pkg/hash

Fungsi:

```go
HashPassword(password string) (string, error)
CheckPassword(hash, password string) bool
```

### pkg/token

Fungsi:

```go
GenerateQRCodeToken() string
GeneratePublicID() uuid.UUID
```

### pkg/datetime

Fungsi:

```go
NowInTimezone(tz string) time.Time
TodayInTimezone(tz string) time.Time
DateOnly(t time.Time) time.Time
DaysRemaining(endDate time.Time, now time.Time) int
```

### pkg/invoice

Fungsi:

```go
GenerateInvoiceNo(date time.Time, sequence int) string
```

### pkg/sqlutil

Fungsi:

```go
LikeSearch(keyword string) string
BuildOrderBy(allowed map[string]string, requested string, fallback string) string
```

Jangan membuat SQL helper yang rentan injection. Order by harus whitelist.

## 10. Transaction Pattern

Buat helper transaction:

```go
func WithTx(ctx context.Context, db *pgxpool.Pool, fn func(tx pgx.Tx) error) error {
    tx, err := db.Begin(ctx)
    if err != nil {
        return err
    }

    defer func() {
        if p := recover(); p != nil {
            _ = tx.Rollback(ctx)
            panic(p)
        }
    }()

    if err := fn(tx); err != nil {
        _ = tx.Rollback(ctx)
        return err
    }

    return tx.Commit(ctx)
}
```

Repository yang perlu transaction harus punya versi method menerima `pgx.Tx` atau interface:

```go
type DBTX interface {
    Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error)
    QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
    Exec(ctx context.Context, sql string, args ...any) (pgconn.CommandTag, error)
}
```

## 11. Docker Compose

Minimal service:

```yaml
services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    working_dir: /app
    ports:
      - "8080:8080"
    volumes:
      - .:/app
    env_file:
      - .env
    depends_on:
      - postgres
      - redis
    command: air -c .air.toml

  postgres:
    image: postgres:16-alpine
    ports:
      - "5432:5432"
    environment:
      POSTGRES_DB: gym_management
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_data:
```

## 12. Dockerfile Dev

```dockerfile
FROM golang:1.23-alpine

RUN apk add --no-cache git bash curl build-base
RUN go install github.com/air-verse/air@latest
RUN go install github.com/golang-migrate/migrate/v4/cmd/migrate@latest

WORKDIR /app

COPY go.mod go.sum ./
RUN go mod download

COPY . .

EXPOSE 8080

CMD ["air", "-c", ".air.toml"]
```

Catatan:

- Versi Go boleh disesuaikan dengan project lokal.
- Untuk production buat Dockerfile terpisah multi-stage.

## 13. .air.toml

```toml
root = "."
tmp_dir = "tmp"

[build]
cmd = "go build -o ./tmp/main ./cmd/api"
bin = "./tmp/main"
full_bin = "./tmp/main"
include_ext = ["go", "tpl", "tmpl", "html"]
exclude_dir = ["assets", "tmp", "vendor", "migrations"]
delay = 1000
stop_on_error = true
send_interrupt = true
kill_delay = 500

[log]
time = true

[color]
main = "magenta"
watcher = "cyan"
build = "yellow"
runner = "green"
```

## 14. Makefile

```makefile
APP_NAME=gym-management-api
DB_URL=postgres://postgres:postgres@postgres:5432/gym_management?sslmode=disable

.PHONY: dev up down logs test fmt vet migrate-up migrate-down migrate-force migrate-create

dev:
	docker compose up app

up:
	docker compose up -d

down:
	docker compose down

logs:
	docker compose logs -f app

test:
	go test ./...

fmt:
	go fmt ./...

vet:
	go vet ./...

migrate-up:
	docker compose exec app migrate -path migrations -database "$(DB_URL)" up

migrate-down:
	docker compose exec app migrate -path migrations -database "$(DB_URL)" down 1

migrate-force:
	docker compose exec app migrate -path migrations -database "$(DB_URL)" force $(version)

migrate-create:
	docker compose exec app migrate create -ext sql -dir migrations -seq $(name)
```

Jika migrate dijalankan dari host, DB host gunakan `localhost`, bukan `postgres`.

## 15. .env.example

```env
APP_ENV=development
APP_PORT=8080
APP_URL=http://localhost:8080
PUBLIC_MEMBER_URL=http://localhost:3000/member/checkin

DB_HOST=postgres
DB_PORT=5432
DB_NAME=gym_management
DB_USER=postgres
DB_PASSWORD=postgres
DB_SSLMODE=disable

REDIS_ADDR=redis:6379
REDIS_PASSWORD=
REDIS_DB=0

JWT_ACCESS_SECRET=change_me_access_secret
JWT_REFRESH_SECRET=change_me_refresh_secret
JWT_ACCESS_TTL_MINUTES=60
JWT_REFRESH_TTL_HOURS=168

DEFAULT_TIMEZONE=Asia/Jakarta
DEFAULT_CURRENCY=IDR
```

## 16. Route Registration Pattern

`internal/routes/routes.go`:

```go
func Register(router *gin.Engine, deps Dependencies) {
    api := router.Group("/api/v1")

    RegisterAdminRoutes(api.Group("/admin"), deps)
    RegisterMemberRoutes(api.Group("/member"), deps)
}
```

`admin_routes.go`:

```go
func RegisterAdminRoutes(r *gin.RouterGroup, deps Dependencies) {
    auth := r.Group("/auth")
    auth.POST("/login", deps.AuthController.Login)
    auth.POST("/refresh", deps.AuthController.Refresh)

    protected := r.Group("")
    protected.Use(deps.AuthMiddleware.RequireAuth())

    protected.POST("/auth/logout", deps.AuthController.Logout)
    protected.GET("/auth/profile", deps.AuthController.Profile)

    protected.GET("/members", deps.MemberController.List)
    protected.POST("/members", deps.RoleMiddleware.Require("owner", "admin", "cashier"), deps.MemberController.Create)
}
```

## 17. Middleware Auth Context

Auth middleware harus inject struct:

```go
type AuthUser struct {
    UserID      int64
    UserPublicID uuid.UUID
    GymID       int64
    GymPublicID uuid.UUID
    Role        string
}
```

Access:

```go
authUser := middleware.GetAuthUser(ctx)
```

## 18. Query Rules

Wajib:

```sql
WHERE gym_id = $1
```

Untuk semua admin data:

- users
- members
- packages
- subscriptions
- payments
- expenses
- qrcodes
- checkins
- reminders
- audits

Public by qr token:

- Cari qrcode by `qr_token` dan `status = active`.
- Ambil `gym_id` dari qrcode.
- Query lanjut scoped by gym_id.

## 19. Migration SQL Skeleton

Gunakan `uuid` generated dari aplikasi, bukan default DB, agar konsisten dari service. Namun boleh aktifkan extension:

```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
```

Gunakan:

```sql
created_at TIMESTAMP NOT NULL DEFAULT NOW(),
updated_at TIMESTAMP NOT NULL DEFAULT NOW()
```

Untuk `updated_at`, update dari aplikasi.

## 20. Testing Minimal

Unit test prioritas:

1. Pagination helper.
2. Password hash/check.
3. JWT parse/generate.
4. Date helper.
5. Payment final amount calculation.
6. Check-in validation service.
7. QR regenerate logic.

Service test dapat menggunakan mock repository.
