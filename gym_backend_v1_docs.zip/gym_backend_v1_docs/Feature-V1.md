# Feature-V1.md - Gym Management SaaS V1

Dokumen ini menjelaskan fitur bisnis V1 yang wajib selesai.

## 1. Scope V1

V1 fokus pada core bisnis gym:

```text
Admin Auth
Gym Profile
Staff/User
Member
Membership Package
Subscription
Payment
Expense
QR Member
Check-in
Reminder
Report
Audit Log
Public Member API
```

Tidak termasuk V1:

```text
RBAC dinamis
Workout schedule
Exercise timer
Weight progress
Payment gateway real
WhatsApp provider real
SaaS billing owner gym
POS produk
```

---

## 2. Multi Tenant Gym

Setiap data bisnis punya `gym_id`.

Rules:

1. User admin hanya boleh akses data gym miliknya.
2. Semua repository admin wajib filter `gym_id`.
3. Jangan pernah list semua data tanpa `gym_id`.
4. `public_id` digunakan di API.
5. `id` internal hanya untuk join dan foreign key.

---

## 3. Roles V1

Role masih statis di kolom `users.role`.

| Role | Hak akses |
|---|---|
| owner | Semua fitur |
| admin | Semua operasional kecuali fitur owner khusus |
| cashier | Member, payment, check-in, expense dasar |
| trainer | Read-only member aktif dan check-in |

V1 belum RBAC dinamis.

---

## 4. Auth Admin

Fitur:

- Login admin/staff.
- Logout.
- Refresh token.
- Profile.
- Middleware JWT.
- Middleware role.

Rules:

- Password wajib bcrypt.
- Token berisi `user_id`, `gym_id`, `role`.
- Refresh token simpan di Redis.
- User nonaktif tidak boleh login.
- Gym nonaktif/suspended tidak boleh login.

---

## 5. Gym Profile

Fitur:

- Lihat profil gym.
- Update profil gym.

Field yang bisa update:

```text
name
phone
email
address
timezone
currency
```

---

## 6. Staff/User Management

Fitur:

- List staff.
- Create staff.
- Detail staff.
- Update staff.
- Deactivate staff.

Rules:

- Email unik per gym.
- Delete = `is_active = false`.
- Role hanya boleh: owner, admin, cashier, trainer.
- Cashier/trainer tidak boleh membuat owner/admin.

---

## 7. Member Management

Fitur:

- List member.
- Search member.
- Filter status.
- Create member.
- Detail member.
- Update member.
- Deactivate member.

Rules:

- `member_code` unik per gym.
- Delete = status `inactive`.
- Data emergency contact hanya admin endpoint, jangan tampilkan di public.

---

## 8. Membership Package

Fitur:

- List package.
- Create package.
- Detail package.
- Update package.
- Deactivate package.

Rules:

- `duration_days` harus > 0.
- `price` harus >= 0.
- Delete = `is_active = false`.

---

## 9. Subscription

Fitur:

- List subscription.
- Create subscription manual.
- Detail subscription.
- Cancel subscription.
- Expire subscription by system/admin.

Rules active subscription:

```text
status = active
start_date <= today
end_date >= today
```

Rules create:

- Member harus active.
- Package harus active.
- `end_date = start_date + duration_days - 1 day` atau sesuai keputusan bisnis.

Rekomendasi:

Jika paket 30 hari mulai 2026-06-01, end_date = 2026-06-30.

---

## 10. Payment

Fitur:

- List payment.
- Create payment membership.
- Detail payment.
- Cancel payment.
- Refund payment.

Payment membership flow:

```text
1. Validate member active.
2. Validate package active.
3. Calculate package_price.
4. Validate discount_amount >= 0 and <= package_price.
5. Calculate final_amount = package_price - discount_amount.
6. Create subscription.
7. Create payment.
8. Generate invoice_no.
9. Audit log.
```

Payment methods:

```text
cash, transfer, qris
```

Payment statuses:

```text
paid, pending, cancelled, refunded
```

Rules:

- `paid_at` required for paid payment.
- Cancel/refund should not delete data.
- If payment cancelled/refunded, subscription handling must be explicit.

Rekomendasi V1:

- Cancel payment: set payment `cancelled`, subscription `cancelled`.
- Refund payment: set payment `refunded`, subscription `cancelled`.

---

## 11. Expense

Fitur:

- Expense category CRUD.
- Expense CRUD.
- Approve expense.
- Reject expense.

Rules:

- Hanya expense `approved` masuk profit-loss.
- Category delete = `is_active = false`.

---

## 12. Member QR Code

Fitur:

- Get QR member.
- Generate QR.
- Regenerate QR.
- Revoke QR.

Rules:

- QR berisi token random, bukan member id.
- QR token unik global.
- Member hanya boleh punya satu active QR token.
- Regenerate: revoke token lama, buat token baru.
- Revoke: token lama tidak bisa dipakai scan.

Saran QR content:

```text
https://app-domain.com/member/checkin/{qr_token}
```

---

## 13. Check-in

Fitur:

- Admin scan QR.
- Admin manual check-in.
- Public member scan QR.
- List check-in.
- Today check-in.
- History check-in member.

Validation scan QR:

```text
1. QR token harus ada dan active.
2. Member harus active.
3. Subscription harus active hari ini.
4. Tidak boleh ada check-in valid untuk member yang sama pada tanggal yang sama.
5. Jika valid, create member_checkins status valid.
```

Status check-in:

```text
valid
invalid_qr
expired
inactive_member
duplicate
cancelled
```

Duplicate rule:

- 1 member hanya boleh 1 check-in valid per hari.
- Gunakan partial unique index Postgres.

Public check-in:

- `scanned_by = null`
- `source = qr`

Admin check-in:

- `scanned_by = admin_user_id`
- `source = qr` atau `manual`

---

## 14. Public Member API

Public member API berbasis `qr_token`.

Fitur:

- Lihat QR identity/member summary.
- Cek membership status.
- Check-in scan.
- Lihat history check-in.
- Lihat package aktif gym.
- Lihat kontak gym.

Data yang boleh tampil public:

```text
member_name
member_code
gym_name
membership_status
subscription_start_date
subscription_end_date
days_remaining
checkin history
package list
contact gym
```

Data yang tidak boleh tampil public:

```text
email
alamat lengkap
emergency contact
notes internal
payment detail
audit log
created_by
internal id
```

---

## 15. Reminder

Fitur:

- Reminder rule CRUD.
- Reminder logs.
- Retry reminder log.

V1 provider boleh stub.

Rules:

- Rule: H-berapa sebelum subscription expired.
- Channel V1: whatsapp/email sebagai string.
- Logs menyimpan status pending/sent/failed.
- Error provider simpan di `error_message`.

---

## 16. Reports

Reports V1:

1. Dashboard.
2. Payments.
3. Expenses.
4. Profit-loss.
5. Check-ins.
6. Expired members.

Dashboard fields:

```text
total_active_members
total_expired_members
income_this_month
expense_this_month
net_profit_this_month
checkins_today
payment_pending
reminder_failed
```

Profit-loss:

```text
total_income = sum paid payments
total_expense = sum approved expenses
net_profit = total_income - total_expense
```

---

## 17. Audit Log

Wajib catat:

- User create/update/deactivate.
- Member create/update/deactivate.
- Package create/update/deactivate.
- Subscription create/cancel/expire.
- Payment create/cancel/refund.
- Expense create/update/approve/reject.
- QR generate/regenerate/revoke.
- Manual check-in.
- Reminder rule changes.

Payload JSON boleh berisi before/after ringkas.

Contoh action:

```text
member.created
member.updated
member.deactivated
payment.created
payment.refunded
checkin.created
qrcode.regenerated
```
