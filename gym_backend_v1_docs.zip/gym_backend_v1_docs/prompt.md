# prompt.md - Master Prompt untuk Codex / Claude Code

Gunakan prompt ini untuk memulai vibe coding backend Gym Management SaaS V1.

---

## MASTER PROMPT

Kamu adalah senior backend engineer Golang. Bangun backend API untuk **Gym Management SaaS V1** berdasarkan dokumen berikut:

1. `AGENTIC_LOOP.md`
2. `dbdiagram.md`
3. `Feature-V1.md`
4. `restendpointapi-and-payload.md`
5. `Patterncode-structurepath.md`

Stack wajib:

- Golang
- Gin Framework
- PostgreSQL
- Redis
- Docker Compose
- SQL migration dengan golang-migrate
- Hot reload dengan Air

Pattern wajib:

```text
Controller -> Service -> Repository -> Models/Base Query -> Database
```

Rules wajib:

1. Controller hanya HTTP binding/validation/response.
2. Service untuk business logic dan transaction.
3. Repository untuk SQL query.
4. Models untuk struct table, enum, scanner, dan base query.
5. Helper untuk fungsi reusable seperti pagination, response, JWT, bcrypt, date, invoice, QR token.
6. Semua admin query wajib scoped by `gym_id`.
7. API path menggunakan `public_id`, jangan expose internal numeric `id`.
8. Public member API hanya menggunakan `qr_token` dan tidak boleh expose data sensitif.
9. Semua create/update/delete penting masuk `audit_logs`.
10. Migration up/down wajib dibuat.
11. Docker Compose wajib jalan dengan PostgreSQL dan Redis.
12. Hot reload wajib menggunakan Air.
13. Format response wajib konsisten.

Core fitur V1:

- Admin auth
- Gym profile
- Staff/users
- Members
- Membership packages
- Subscriptions
- Payments
- Expense categories
- Expenses
- Member QR codes
- Member check-ins
- Reminder rules
- Reminder logs
- Reports
- Audit logs
- Public member endpoints

Jangan implement V2 dulu:

- Workout schedule
- Exercise timer
- Weight logs
- RBAC dinamis
- SaaS billing owner gym
- POS produk

---

## IMPLEMENTATION ORDER

Kerjakan secara bertahap. Jangan lompat.

### Step 1 - Foundation

Buat project structure sesuai `Patterncode-structurepath.md`.

Buat file:

```text
cmd/api/main.go
config/config.go
database/postgres.go
database/redis.go
internal/app/app.go
internal/routes/routes.go
internal/routes/admin_routes.go
internal/routes/member_routes.go
internal/middleware/*
pkg/response/*
pkg/pagination/*
pkg/errors/*
pkg/auth/*
pkg/hash/*
pkg/token/*
pkg/datetime/*
pkg/invoice/*
pkg/sqlutil/*
Dockerfile
docker-compose.yml
.air.toml
Makefile
.env.example
.gitignore
```

Acceptance:

```bash
docker compose up app
GET /health returns OK
```

### Step 2 - Migration

Buat migration:

```text
migrations/000001_create_core_schema.up.sql
migrations/000001_create_core_schema.down.sql
```

Schema harus sesuai `dbdiagram.md`.

Wajib ada partial unique index:

```sql
CREATE UNIQUE INDEX uniq_valid_checkin_per_member_per_day
ON member_checkins (gym_id, member_id, checkin_date)
WHERE status = 'valid';
```

Acceptance:

```bash
make migrate-up
make migrate-down
make migrate-up
```

### Step 3 - Shared Models

Buat semua models:

```text
internal/models/gym.go
internal/models/user.go
internal/models/member.go
internal/models/membership_package.go
internal/models/subscription.go
internal/models/payment.go
internal/models/expense_category.go
internal/models/expense.go
internal/models/member_qrcode.go
internal/models/member_checkin.go
internal/models/reminder_rule.go
internal/models/reminder_log.go
internal/models/audit_log.go
```

Models harus punya:

- struct
- enum const
- scanner helper jika diperlukan

### Step 4 - Auth

Implement:

```http
POST /api/v1/admin/auth/login
POST /api/v1/admin/auth/logout
POST /api/v1/admin/auth/refresh
GET  /api/v1/admin/auth/profile
```

Gunakan:

- bcrypt
- JWT
- Redis refresh token

Acceptance:

- User aktif bisa login.
- User inactive tidak bisa login.
- JWT valid bisa akses profile.

### Step 5 - Gym/User/Member

Implement CRUD:

- Gym profile
- Users/staff
- Members

Acceptance:

- List pagination jalan.
- Search/filter jalan.
- Audit log dibuat.
- Query scoped by gym_id.

### Step 6 - Packages/Subscriptions/Payments

Implement:

- Membership packages CRUD.
- Subscription manual create/cancel/expire.
- Payment membership create.
- Payment cancel/refund.

Payment create wajib transaction:

```text
create subscription + create payment + audit log
```

Acceptance:

- Membuat payment membership otomatis membuat subscription.
- Invoice number unik per gym.
- Discount dihitung benar.

### Step 7 - Expense

Implement:

- Expense categories CRUD.
- Expenses CRUD.
- Approve/reject.

Acceptance:

- Expense approved masuk report.
- Expense draft/rejected tidak masuk profit-loss.

### Step 8 - QR Code & Check-in

Implement:

- Member QR get/generate/regenerate/revoke.
- Admin scan QR.
- Admin manual check-in.
- Public member scan QR.
- Check-in list/today/history.

Rules scan:

```text
validate qr -> validate member -> validate subscription -> validate duplicate -> create checkin
```

Acceptance:

- QR invalid return error.
- Member inactive return error.
- Subscription expired return error with member summary.
- Duplicate same day return error.
- Valid check-in sukses.

### Step 9 - Public Member API

Implement:

```http
GET  /api/v1/member/qrcode/{qr_token}
GET  /api/v1/member/status/{qr_token}
POST /api/v1/member/checkins/scan
GET  /api/v1/member/checkins/{qr_token}
GET  /api/v1/member/packages/{qr_token}
GET  /api/v1/member/gym/{qr_token}
```

Acceptance:

- Tidak expose email/alamat/emergency contact/notes/payment.
- qr_token revoked tidak bisa dipakai.

### Step 10 - Reminder/Reports/Audit

Implement:

- Reminder rules CRUD.
- Reminder logs list/retry stub.
- Reports dashboard/payments/expenses/profit-loss/checkins/expired-members.
- Audit logs list.

Acceptance:

- Dashboard menghasilkan data benar.
- Profit-loss hanya hitung paid payments dan approved expenses.
- Audit log list bisa filter entity_type.

---

## CODING STYLE

Gunakan gaya ini:

1. Nama package singular sesuai modul: `member`, `payment`, `checkin`.
2. DTO file bernama `{module}_dto.go`.
3. Constructor dependency explicit.
4. Context selalu dikirim ke repository.
5. Query timeout jika helper tersedia.
6. Error pakai typed app error.
7. Response tidak langsung pakai `ctx.JSON` kecuali di `pkg/response`.
8. Semua request pakai validation tag dan/atau Validate method.

---

## COMMANDS

Setelah implement tiap step, jalankan:

```bash
go fmt ./...
go vet ./...
go test ./...
```

Dengan Docker:

```bash
docker compose up -d
make migrate-up
make logs
```

---

## STOP CONDITION

Berhenti dan laporkan jika:

1. Ada conflict besar antar dokumen.
2. Migration gagal dan butuh keputusan schema.
3. Ada endpoint ambigu yang bisa mengubah core bisnis.

Jika tidak ada conflict, lanjutkan implementasi sampai acceptance step terpenuhi.
