# Gym Management SaaS Backend V1 Docs

Dokumen ini dibuat sebagai instruksi kerja untuk membangun backend **Gym Management SaaS V1** menggunakan:

- Golang
- Gin Framework
- PostgreSQL
- Redis
- Docker Compose
- Migration SQL
- Hot reload dengan Air
- Pattern: Controller, Service, Repository, Models

Target V1:

1. Core bisnis membership gym berjalan.
2. Admin dashboard API tersedia.
3. Public member API tersedia untuk QR member/check-in.
4. Struktur kode rapi, testable, dan mudah dikembangkan ke V2.

## Urutan baca dokumen

1. `AGENTIC_LOOP.md`
2. `dbdiagram.md`
3. `Feature-V1.md`
4. `restendpointapi-and-payload.md`
5. `Patterncode-structurepath.md`
6. `prompt.md`

## Prinsip penting

- Jangan hard delete data bisnis utama. Gunakan status atau soft behavior.
- Semua query wajib scoped by `gym_id` untuk mencegah data antar gym tercampur.
- Public API member hanya boleh menampilkan data aman.
- Gunakan `public_id` untuk URL/API, jangan expose `id` internal database.
- Semua create/update/delete penting wajib dicatat ke `audit_logs`.
- Check-in QR wajib validasi QR, member, subscription, dan duplicate harian.
